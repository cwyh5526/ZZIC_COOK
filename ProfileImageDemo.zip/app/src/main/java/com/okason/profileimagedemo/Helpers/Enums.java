package com.okason.profileimagedemo.Helpers;

/**
 * Created by Valentine on 4/7/2015.
 */
public class Enums {

    public enum FragmentEnums
    {
        CustomerDetailsFragment,
        ProductDetailsFragment,
        OrderDetailsFragment
    }


}



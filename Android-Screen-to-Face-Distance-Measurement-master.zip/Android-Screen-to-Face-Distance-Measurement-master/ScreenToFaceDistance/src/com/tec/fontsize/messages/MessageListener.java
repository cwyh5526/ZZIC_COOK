package com.tec.fontsize.messages;

public interface MessageListener {

	public void onMessage(int messageID, Object message);

}
